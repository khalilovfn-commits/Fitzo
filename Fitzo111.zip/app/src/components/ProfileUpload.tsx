import { useState, useRef } from 'react';
import { Camera, X, User } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface ProfileUploadProps {
  onImageSelect: (imageUrl: string | null) => void;
  selectedImage: string | null;
  t: Record<string, string>;
}

export function ProfileUpload({ onImageSelect, selectedImage, t }: ProfileUploadProps) {
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      processFile(file);
    }
  };

  const processFile = (file: File) => {
    if (!file.type.startsWith('image/')) {
      return;
    }
    
    const reader = new FileReader();
    reader.onload = (e) => {
      const result = e.target?.result as string;
      onImageSelect(result);
    };
    reader.readAsDataURL(file);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    const file = e.dataTransfer.files[0];
    if (file && file.type.startsWith('image/')) {
      processFile(file);
    }
  };

  const handleRemoveImage = () => {
    onImageSelect(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className="flex flex-col items-center gap-4">
      <div
        onClick={() => fileInputRef.current?.click()}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        className={`
          relative w-32 h-32 rounded-full cursor-pointer overflow-hidden
          transition-all duration-300 group
          ${isDragging 
            ? 'ring-4 ring-indigo-500 ring-offset-4 ring-offset-slate-900' 
            : 'ring-2 ring-white/20 hover:ring-indigo-500/50'
          }
          ${selectedImage ? '' : 'bg-gradient-to-br from-indigo-500/20 to-purple-500/20'}
        `}
      >
        {selectedImage ? (
          <>
            <img
              src={selectedImage}
              alt="Profile"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
              <Camera className="w-8 h-8 text-white" />
            </div>
          </>
        ) : (
          <div className="w-full h-full flex flex-col items-center justify-center text-slate-400 group-hover:text-indigo-400 transition-colors">
            <User className="w-12 h-12 mb-2" />
            <span className="text-xs text-center px-2">
              {t.addPhoto || 'Fotoğraf Ekle'}
            </span>
          </div>
        )}
        
        {/* Camera icon badge */}
        <div className="absolute bottom-0 right-0 w-10 h-10 bg-indigo-600 rounded-full flex items-center justify-center shadow-lg border-2 border-slate-800">
          <Camera className="w-5 h-5 text-white" />
        </div>
      </div>

      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        onChange={handleFileChange}
        className="hidden"
      />

      {selectedImage && (
        <Button
          variant="ghost"
          size="sm"
          onClick={handleRemoveImage}
          className="text-slate-400 hover:text-red-400"
        >
          <X className="w-4 h-4 mr-1" />
          {t.remove || 'Kaldır'}
        </Button>
      )}

      <p className="text-xs text-slate-500 text-center">
        {t.dragDrop || 'Fotoğrafı sürükleyin veya tıklayın'}
      </p>
    </div>
  );
}

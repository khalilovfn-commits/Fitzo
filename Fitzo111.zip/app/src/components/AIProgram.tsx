import { useState } from 'react';
import { Sparkles, Loader2, ChevronDown, ChevronUp, Lightbulb, TrendingUp, Utensils } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useAI } from '@/hooks/useAI';

interface AIProgramGeneratorProps {
  userProfile: {
    height: number;
    weight: number;
    age: number;
    gender: 'male' | 'female';
    goal: 'loseWeight' | 'buildMuscle' | 'maintain';
    experience: 'beginner' | 'intermediate' | 'advanced';
    trainingDays: 3 | 4 | 5 | 6;
  };
  language: string;
  t: Record<string, string>;
}

const translations = {
  ru: {
    generateAI: 'Создать AI программу',
    generating: 'AI создает программу...',
    programName: 'Название программы',
    description: 'Описание',
    weeklySchedule: 'Расписание на неделю',
    nutritionTips: 'Советы по питанию',
    progression: 'Стратегия прогресса',
    warmup: 'Разминка',
    cooldown: 'Заминка',
    sets: 'подходы',
    reps: 'повторы',
    rest: 'отдых',
    tips: 'Советы',
    day: 'День',
    restDay: 'Выходной'
  },
  tr: {
    generateAI: 'AI Program Oluştur',
    generating: 'AI program oluşturuyor...',
    programName: 'Program Adı',
    description: 'Açıklama',
    weeklySchedule: 'Haftalık Program',
    nutritionTips: 'Beslenme İpuçları',
    progression: 'İlerleme Stratejisi',
    warmup: 'Isınma',
    cooldown: 'Soğuma',
    sets: 'set',
    reps: 'tekrar',
    rest: 'dinlenme',
    tips: 'İpuçları',
    day: 'Gün',
    restDay: 'Dinlenme Günü'
  },
  en: {
    generateAI: 'Generate AI Program',
    generating: 'AI is generating program...',
    programName: 'Program Name',
    description: 'Description',
    weeklySchedule: 'Weekly Schedule',
    nutritionTips: 'Nutrition Tips',
    progression: 'Progression Strategy',
    warmup: 'Warm-up',
    cooldown: 'Cool-down',
    sets: 'sets',
    reps: 'reps',
    rest: 'rest',
    tips: 'Tips',
    day: 'Day',
    restDay: 'Rest Day'
  },
  az: {
    generateAI: 'AI Program Yarat',
    generating: 'AI program yaradır...',
    programName: 'Program Adı',
    description: 'Təsvir',
    weeklySchedule: 'Həftəlik Cədvəl',
    nutritionTips: 'Qidalanma Məsləhətləri',
    progression: 'İrəliləyiş Strategiyası',
    warmup: 'Isınma',
    cooldown: 'Soyuma',
    sets: 'set',
    reps: 'təkrar',
    rest: 'istirahət',
    tips: 'Məsləhətlər',
    day: 'Gün',
    restDay: 'Istirahət Günü'
  }
};

export function AIProgramGenerator({ userProfile, language }: AIProgramGeneratorProps) {
  const { generateAIProgram, aiProgram, isGenerating } = useAI();
  const [expandedDay, setExpandedDay] = useState<number | null>(null);
  
  const t = translations[language as keyof typeof translations] || translations.en;

  const handleGenerate = () => {
    generateAIProgram(userProfile);
  };

  const toggleDay = (day: number) => {
    setExpandedDay(expandedDay === day ? null : day);
  };

  if (!aiProgram && !isGenerating) {
    return (
      <Card className="bg-gradient-to-br from-indigo-900/50 to-purple-900/50 border-indigo-500/30">
        <CardContent className="p-8 text-center">
          <div className="w-16 h-16 rounded-full bg-indigo-500/20 flex items-center justify-center mx-auto mb-4">
            <Sparkles className="w-8 h-8 text-indigo-400" />
          </div>
          <h3 className="text-xl font-bold text-white mb-2">
            {language === 'tr' ? 'AI ile Kişiselleştirilmiş Program' : 
             language === 'ru' ? 'Персонализированная программа с AI' :
             language === 'az' ? 'AI ilə Fərdiləşdirilmiş Proqram' : 'AI Personalized Program'}
          </h3>
          <p className="text-slate-400 mb-6 max-w-md mx-auto">
            {language === 'tr' ? 'Yapay zeka, hedeflerinize ve vücut tipinize özel detaylı bir program oluşturacak.' :
             language === 'ru' ? 'ИИ создаст детальную программу, адаптированную под ваши цели и тип тела.' :
             language === 'az' ? 'Süni intellekt hədəflərinizə və bədən tipinizə uyğun detallı proqram yaradacaq.' :
             'AI will create a detailed program tailored to your goals and body type.'}
          </p>
          <Button
            onClick={handleGenerate}
            className="gradient-primary text-white px-8"
          >
            <Sparkles className="w-5 h-5 mr-2" />
            {t.generateAI}
          </Button>
        </CardContent>
      </Card>
    );
  }

  if (isGenerating) {
    return (
      <Card className="bg-slate-800/50 border-white/10">
        <CardContent className="p-12 text-center">
          <Loader2 className="w-12 h-12 text-indigo-400 animate-spin mx-auto mb-4" />
          <p className="text-white text-lg">{t.generating}</p>
          <p className="text-slate-400 text-sm mt-2">
            {language === 'tr' ? 'Bu birkaç saniye sürebilir...' :
             language === 'ru' ? 'Это может занять несколько секунд...' :
             language === 'az' ? 'Bu bir neçə saniyə çəkə bilər...' :
             'This may take a few seconds...'}
          </p>
        </CardContent>
      </Card>
    );
  }

  if (!aiProgram) return null;

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Program Header */}
      <Card className="bg-gradient-to-br from-indigo-900/50 to-purple-900/50 border-indigo-500/30">
        <CardHeader>
          <div className="flex items-center gap-3 mb-2">
            <Sparkles className="w-6 h-6 text-indigo-400" />
            <Badge className="bg-indigo-500/20 text-indigo-300 border-indigo-500/30">
              AI Powered
            </Badge>
          </div>
          <CardTitle className="text-2xl text-white">{aiProgram.programName}</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-slate-300">{aiProgram.description}</p>
        </CardContent>
      </Card>

      {/* Weekly Schedule */}
      <div>
        <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
          <TrendingUp className="w-5 h-5 text-indigo-400" />
          {t.weeklySchedule}
        </h3>
        
        <div className="space-y-3">
          {aiProgram.weeklySchedule.map((day) => (
            <Card 
              key={day.day} 
              className={`border-white/10 ${day.exercises.length === 0 ? 'bg-slate-800/30' : 'bg-slate-800/50'}`}
            >
              <div 
                className="p-4 flex items-center justify-between cursor-pointer"
                onClick={() => day.exercises.length > 0 && toggleDay(day.day)}
              >
                <div className="flex items-center gap-3">
                  <span className="w-8 h-8 rounded-full bg-indigo-500/20 flex items-center justify-center text-indigo-400 font-bold text-sm">
                    {day.day}
                  </span>
                  <div>
                    <p className="text-white font-medium">{day.focus}</p>
                    {day.exercises.length > 0 && (
                      <p className="text-slate-400 text-sm">
                        {day.exercises.length} {language === 'tr' ? 'egzersiz' : 
                                                  language === 'ru' ? 'упражнений' :
                                                  language === 'az' ? 'məşq' : 'exercises'}
                      </p>
                    )}
                  </div>
                </div>
                {day.exercises.length > 0 && (
                  expandedDay === day.day ? 
                    <ChevronUp className="w-5 h-5 text-slate-400" /> : 
                    <ChevronDown className="w-5 h-5 text-slate-400" />
                )}
              </div>

              {expandedDay === day.day && day.exercises.length > 0 && (
                <CardContent className="pt-0">
                  {/* Warmup */}
                  {day.warmup.length > 0 && (
                    <div className="mb-4 p-3 bg-orange-500/10 rounded-lg border border-orange-500/20">
                      <p className="text-orange-400 text-sm font-medium mb-1">🔥 {t.warmup}</p>
                      <ul className="text-slate-400 text-sm list-disc list-inside">
                        {day.warmup.map((item, i) => (
                          <li key={i}>{item}</li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {/* Exercises */}
                  <div className="space-y-2">
                    {day.exercises.map((exercise, idx) => (
                      <div 
                        key={idx}
                        className="p-3 bg-slate-900/50 rounded-lg"
                      >
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-white font-medium">{exercise.name}</span>
                          <span className="text-indigo-400 text-sm">
                            {exercise.sets} {t.sets} × {exercise.reps}
                          </span>
                        </div>
                        <div className="flex items-center gap-4 text-xs text-slate-400">
                          <span>⏱️ {t.rest}: {exercise.rest}</span>
                        </div>
                        <p className="text-slate-500 text-xs mt-1">
                          💡 {t.tips}: {exercise.tips}
                        </p>
                      </div>
                    ))}
                  </div>

                  {/* Cooldown */}
                  {day.cooldown.length > 0 && (
                    <div className="mt-4 p-3 bg-blue-500/10 rounded-lg border border-blue-500/20">
                      <p className="text-blue-400 text-sm font-medium mb-1">❄️ {t.cooldown}</p>
                      <ul className="text-slate-400 text-sm list-disc list-inside">
                        {day.cooldown.map((item, i) => (
                          <li key={i}>{item}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                </CardContent>
              )}
            </Card>
          ))}
        </div>
      </div>

      {/* Nutrition Tips */}
      <Card className="bg-slate-800/50 border-white/10">
        <CardHeader>
          <CardTitle className="text-lg text-white flex items-center gap-2">
            <Utensils className="w-5 h-5 text-green-400" />
            {t.nutritionTips}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2">
            {aiProgram.nutritionTips.map((tip, idx) => (
              <li key={idx} className="flex items-start gap-2 text-slate-300 text-sm">
                <span className="text-green-400 mt-0.5">✓</span>
                {tip}
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>

      {/* Progression Strategy */}
      <Card className="bg-slate-800/50 border-white/10">
        <CardHeader>
          <CardTitle className="text-lg text-white flex items-center gap-2">
            <Lightbulb className="w-5 h-5 text-yellow-400" />
            {t.progression}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-slate-300 text-sm">{aiProgram.progressionStrategy}</p>
        </CardContent>
      </Card>

      {/* Regenerate Button */}
      <div className="flex justify-center">
        <Button
          onClick={handleGenerate}
          variant="outline"
          className="border-indigo-500/30 text-indigo-400 hover:bg-indigo-500/10"
        >
          <Sparkles className="w-4 h-4 mr-2" />
          {language === 'tr' ? 'Yeni Program Oluştur' :
           language === 'ru' ? 'Создать новую программу' :
           language === 'az' ? 'Yeni Proqram Yarat' :
           'Generate New Program'}
        </Button>
      </div>
    </div>
  );
}

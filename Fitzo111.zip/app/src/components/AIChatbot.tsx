import { useState, useRef, useEffect } from 'react';
import { X, Send, Loader2, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Card } from '@/components/ui/card';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

interface AIChatbotProps {
  isOpen: boolean;
  onClose: () => void;
  userProfile: {
    height: number;
    weight: number;
    age: number;
    gender: string;
    goal: string;
    experience: string;
    trainingDays: number;
  } | null;
  language: string;
}

const translations = {
  ru: {
    title: 'AI Фитнес Ассистент',
    placeholder: 'Задайте вопрос о тренировках...',
    welcome: 'Привет! Я ваш AI фитнес-ассистент. Чем могу помочь?',
    thinking: 'Думаю...',
    suggestions: ['Как правильно приседать?', 'Сколько белка мне нужно?', 'Как увеличить жим лежа?']
  },
  tr: {
    title: 'AI Fitness Asistanı',
    placeholder: 'Antrenman hakkında soru sorun...',
    welcome: 'Merhaba! Ben AI fitness asistanınızım. Size nasıl yardımcı olabilirim?',
    thinking: 'Düşünüyorum...',
    suggestions: ['Squat nasıl yapılır?', 'Ne kadar protein almalıyım?', 'Bench press nasıl artırılır?']
  },
  en: {
    title: 'AI Fitness Assistant',
    placeholder: 'Ask about workouts...',
    welcome: 'Hi! I\'m your AI fitness assistant. How can I help you?',
    thinking: 'Thinking...',
    suggestions: ['How to squat properly?', 'How much protein do I need?', 'How to increase bench press?']
  },
  az: {
    title: 'AI Fitness Köməkçisi',
    placeholder: 'Məşq haqqında sual verin...',
    welcome: 'Salam! Mən AI fitness köməkçisinizəm. Sizə necə kömək edə bilərəm?',
    thinking: 'Düşünürəm...',
    suggestions: ['Squat necə edilir?', 'Nə qədər protein almalıyam?', 'Bench press necə artırılır?']
  }
};

// AI Response generator based on fitness knowledge
function generateAIResponse(question: string, profile: AIChatbotProps['userProfile'], lang: string): string {
  const q = question.toLowerCase();
  
  const responses: Record<string, Record<string, string[]>> = {
    ru: {
      protein: [
        'Для набора мышечной массы рекомендуется 1.6-2.2г белка на кг веса.',
        'Разделите прием белка на 4-5 порций в течение дня.',
        'Источники: курица, рыба, яйца, творог, бобовые.'
      ],
      squat: [
        'Ставьте ноги на ширине плеч, носки слегка наружу.',
        'Опускайтесь до параллели с полом или ниже.',
        'Держите спину прямой, взгляд вперед.',
        'Колени следуют за направлением носков.'
      ],
      bench: [
        'Увеличивайте вес постепенно, по 2.5кг за раз.',
        'Тренируйте технику с легким весом.',
        'Добавьте вспомогательные упражнения: жим узким хватом, отжимания.',
        'Отдыхайте 3-5 минут между подходами.'
      ],
      cardio: [
        'HIIT лучше для сжигания жира.',
        'Низкоинтенсивный кардио после силовой тренировки.',
        '20-30 минут кардио 3-4 раза в неделю оптимально.'
      ]
    },
    tr: {
      protein: [
        'Kas kazanmak için günde 1.6-2.2g protein/kg vücut ağırlığı önerilir.',
        'Protein alımını gün içinde 4-5 öğüne bölün.',
        'Kaynaklar: tavuk, balık, yumurta, lor peyniri, baklagiller.'
      ],
      squat: [
        'Ayaklar omuz genişliğinde, ayak parmakları hafif dışarıya dönük.',
        'Kalça diz hizasına veya altına kadar inin.',
        'Sırt düz, bakış ileriye.',
        'Dizler ayak parmakları yönünde hareket etmeli.'
      ],
      bench: [
        'Ağırlığı yavaşça artırın, her seferinde 2.5kg.',
        'Hafif ağırlıkla teknik çalışın.',
        'Yardımcı egzersizler ekleyin: dar tutuş bench, şınav.',
        'Setler arası 3-5 dakika dinlenin.'
      ],
      cardio: [
        'Yağ yakımı için HIIT daha etkilidir.',
        'Düşük yoğunluklu kardiyo ağırlık antrenmanından sonra.',
        'Haftada 3-4 kez 20-30 dakika kardiyo optimaldir.'
      ]
    },
    en: {
      protein: [
        'For muscle gain, 1.6-2.2g protein per kg bodyweight is recommended.',
        'Split protein intake into 4-5 meals throughout the day.',
        'Sources: chicken, fish, eggs, cottage cheese, legumes.'
      ],
      squat: [
        'Feet shoulder-width apart, toes slightly outward.',
        'Descend until hips are parallel to or below knees.',
        'Keep back straight, look forward.',
        'Knees should track in line with toes.'
      ],
      bench: [
        'Increase weight gradually, 2.5kg at a time.',
        'Practice technique with light weight.',
        'Add accessory exercises: close-grip bench, push-ups.',
        'Rest 3-5 minutes between sets.'
      ],
      cardio: [
        'HIIT is more effective for fat burning.',
        'Low-intensity cardio after strength training.',
        '20-30 minutes cardio 3-4 times per week is optimal.'
      ]
    },
    az: {
      protein: [
        'Əzələ yığmaq üçün gündə 1.6-2.2q protein/kq bədən çəksi tövsiyə olunur.',
        'Protein qəbulunu gün ərzində 4-5 dəfəyə bölün.',
        'Mənbələr: toyuq, balıq, yumurta, qatıq, paxlalılar.'
      ],
      squat: [
        'Ayaqlar çiyin enində, barmaq ucları hafif xaricə.',
        'Çanaq diz həddinə və ya altına qədər enin.',
        'Kürək düz, baxış irəli.',
        'Dizlər barmaq ucu istiqamətində hərəkət etməlidir.'
      ],
      bench: [
        'Çəkini yavaş-yavaş artırın, hər dəfə 2.5kq.',
        'Yüngül çəki ilə texnika işləyin.',
        'Köməkçi məşqlər əlavə edin: dar tutuş bench, şınav.',
        'Setlər arası 3-5 dəqiqə istirahət edin.'
      ],
      cardio: [
        'Yağ yandırmaq üçün HIIT daha effektivdir.',
        'Aşağı intensivlikli kardio ağırlıq məşqindən sonra.',
        'Həftədə 3-4 dəfə 20-30 dəqiqə kardio optimaldır.'
      ]
    }
  };
  
  // Determine topic
  let topic = 'general';
  if (q.includes('protein') || q.includes('белок') || q.includes('белк')) topic = 'protein';
  else if (q.includes('squat') || q.includes('присед')) topic = 'squat';
  else if (q.includes('bench') || q.includes('жим')) topic = 'bench';
  else if (q.includes('cardio') || q.includes('кардио') || q.includes('kardiyo')) topic = 'cardio';
  
  const langResponses = responses[lang] || responses.en;
  
  if (topic !== 'general' && langResponses[topic]) {
    return langResponses[topic].join('\n\n');
  }
  
  // General responses based on profile
  if (profile) {
    const bmi = (profile.weight / Math.pow(profile.height / 100, 2)).toFixed(1);
    const goalText = {
      ru: { loseWeight: 'похудение', buildMuscle: 'набор массы', maintain: 'поддержание' },
      tr: { loseWeight: 'kilo verme', buildMuscle: 'kas kazanma', maintain: 'form koruma' },
      en: { loseWeight: 'weight loss', buildMuscle: 'muscle building', maintain: 'maintenance' },
      az: { loseWeight: 'çəki atma', buildMuscle: 'əzələ yığma', maintain: 'form qoruma' }
    }[lang as keyof typeof translations];
    
    return `BMI'niz: ${bmi}. Hedefiniz: ${goalText?.[profile.goal as keyof typeof goalText] || profile.goal}. ${profile.trainingDays} gün/hafta antrenman planınız var. Size nasıl yardımcı olabilirim?`;
  }
  
  return translations[lang as keyof typeof translations]?.welcome || translations.en.welcome;
}

export function AIChatbot({ isOpen, onClose, userProfile, language }: AIChatbotProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const t = translations[language as keyof typeof translations] || translations.en;

  useEffect(() => {
    if (isOpen && messages.length === 0) {
      setMessages([
        {
          id: 'welcome',
          role: 'assistant',
          content: t.welcome,
          timestamp: new Date()
        }
      ]);
    }
  }, [isOpen, t.welcome]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: input,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsTyping(true);

    // Simulate AI thinking
    await new Promise(resolve => setTimeout(resolve, 1000 + Math.random() * 1000));

    const aiResponse = generateAIResponse(userMessage.content, userProfile, language);

    const assistantMessage: Message = {
      id: (Date.now() + 1).toString(),
      role: 'assistant',
      content: aiResponse,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, assistantMessage]);
    setIsTyping(false);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleSuggestionClick = (suggestion: string) => {
    setInput(suggestion);
  };

  if (!isOpen) return null;

  return (
    <Card className="fixed bottom-4 right-4 w-96 h-[500px] bg-slate-900 border-white/10 shadow-2xl z-50 flex flex-col animate-fadeIn">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-white/10 bg-gradient-to-r from-indigo-600 to-purple-600 rounded-t-lg">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center">
            <Sparkles className="w-4 h-4 text-white" />
          </div>
          <span className="text-white font-semibold">{t.title}</span>
        </div>
        <Button variant="ghost" size="icon" onClick={onClose} className="text-white hover:bg-white/20">
          <X className="w-4 h-4" />
        </Button>
      </div>

      {/* Messages */}
      <ScrollArea className="flex-1 p-4" ref={scrollRef}>
        <div className="space-y-4">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-[80%] rounded-2xl px-4 py-2 text-sm ${
                  message.role === 'user'
                    ? 'bg-indigo-600 text-white'
                    : 'bg-slate-800 text-slate-200 border border-white/10'
                }`}
              >
                {message.content.split('\n\n').map((paragraph, i) => (
                  <p key={i} className={i > 0 ? 'mt-2' : ''}>
                    {paragraph}
                  </p>
                ))}
              </div>
            </div>
          ))}
          
          {isTyping && (
            <div className="flex justify-start">
              <div className="bg-slate-800 text-slate-400 rounded-2xl px-4 py-2 text-sm flex items-center gap-2 border border-white/10">
                <Loader2 className="w-4 h-4 animate-spin" />
                {t.thinking}
              </div>
            </div>
          )}
        </div>

        {/* Suggestions */}
        {messages.length <= 2 && (
          <div className="mt-4 flex flex-wrap gap-2">
            {t.suggestions.map((suggestion, i) => (
              <button
                key={i}
                onClick={() => handleSuggestionClick(suggestion)}
                className="text-xs px-3 py-1.5 rounded-full bg-indigo-500/20 text-indigo-300 hover:bg-indigo-500/30 transition-colors border border-indigo-500/30"
              >
                {suggestion}
              </button>
            ))}
          </div>
        )}
      </ScrollArea>

      {/* Input */}
      <div className="p-4 border-t border-white/10">
        <div className="flex gap-2">
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder={t.placeholder}
            className="flex-1 bg-slate-800 border-white/10 text-white placeholder:text-slate-500"
          />
          <Button
            onClick={handleSend}
            disabled={!input.trim() || isTyping}
            className="bg-indigo-600 hover:bg-indigo-700"
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </Card>
  );
}

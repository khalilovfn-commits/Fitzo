import { useState, useCallback } from 'react';

export interface AIProgramRequest {
  height: number;
  weight: number;
  age: number;
  gender: 'male' | 'female';
  goal: 'loseWeight' | 'buildMuscle' | 'maintain';
  experience: 'beginner' | 'intermediate' | 'advanced';
  trainingDays: number;
  injuries?: string;
  preferences?: string;
}

export interface AIExercise {
  name: string;
  sets: number;
  reps: string;
  rest: string;
  tips: string;
}

export interface AIWorkoutDay {
  day: number;
  focus: string;
  exercises: AIExercise[];
  warmup: string[];
  cooldown: string[];
}

export interface AIProgram {
  programName: string;
  description: string;
  weeklySchedule: AIWorkoutDay[];
  nutritionTips: string[];
  progressionStrategy: string;
}

// AI Fitness Program Generator using local algorithm
export function useAI() {
  const [isGenerating, setIsGenerating] = useState(false);
  const [aiProgram, setAiProgram] = useState<AIProgram | null>(null);

  const generateAIProgram = useCallback(async (request: AIProgramRequest): Promise<AIProgram> => {
    setIsGenerating(true);
    
    // Simulate AI processing delay
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    const program = createSmartProgram(request);
    
    setAiProgram(program);
    setIsGenerating(false);
    
    return program;
  }, []);

  const resetAIProgram = useCallback(() => {
    setAiProgram(null);
  }, []);

  return { generateAIProgram, resetAIProgram, aiProgram, isGenerating };
}

function createSmartProgram(req: AIProgramRequest): AIProgram {
  const { goal, experience, trainingDays, gender, weight, height } = req;
  
  // Calculate BMI for personalized recommendations
  const bmi = weight / Math.pow(height / 100, 2);
  
  // Adjust volume based on experience
  const volumeMultiplier = {
    beginner: 0.7,
    intermediate: 1,
    advanced: 1.3
  }[experience];
  
  // Adjust intensity based on goal
  const intensityConfig = {
    loseWeight: { reps: '12-15', sets: 3, cardio: true },
    buildMuscle: { reps: '8-12', sets: 4, cardio: false },
    maintain: { reps: '10-12', sets: 3, cardio: true }
  }[goal];

  const programName = generateProgramName(goal, experience, trainingDays);
  const description = generateDescription(req, bmi);
  
  const weeklySchedule = generateWeeklySchedule(trainingDays, goal, experience, volumeMultiplier, intensityConfig);
  
  return {
    programName,
    description,
    weeklySchedule,
    nutritionTips: generateNutritionTips(goal, bmi, gender),
    progressionStrategy: generateProgressionStrategy(experience, goal)
  };
}

function generateProgramName(goal: string, experience: string, days: number): string {
  const goalNames = {
    loseWeight: { en: 'Fat Burner', tr: 'Yağ Yakıcı', ru: 'Сжигание жира', az: 'Yağ Yandıran' },
    buildMuscle: { en: 'Muscle Builder', tr: 'Kas Geliştirici', ru: 'Набор массы', az: 'Əzələ Qurucu' },
    maintain: { en: 'Fitness Keeper', tr: 'Form Koruyucu', ru: 'Поддержание формы', az: 'Form Qoruyucu' }
  };
  
  const expNames = {
    beginner: { en: 'Starter', tr: 'Başlangıç', ru: 'Начинающий', az: 'Başlanğıc' },
    intermediate: { en: 'Advanced', tr: 'İleri', ru: 'Продвинутый', az: 'İrəli' },
    advanced: { en: 'Elite', tr: 'Elit', ru: 'Элитный', az: 'Elit' }
  };
  
  return `${goalNames[goal as keyof typeof goalNames].en} ${expNames[experience as keyof typeof expNames].en} - ${days} Day Split`;
}

function generateDescription(req: AIProgramRequest, bmi: number): string {
  let desc = '';
  
  if (req.goal === 'loseWeight') {
    desc = `This ${req.trainingDays}-day program is designed to maximize fat loss while preserving muscle mass. `;
    desc += `With your BMI of ${bmi.toFixed(1)}, we'll focus on high-intensity compound movements `;
    desc += `and strategic cardio placement to create an optimal calorie deficit.`;
  } else if (req.goal === 'buildMuscle') {
    desc = `This hypertrophy-focused ${req.trainingDays}-day split is optimized for muscle growth. `;
    desc += `Progressive overload principles are built into every exercise selection `;
    desc += `to ensure continuous gains for ${req.experience} level trainees.`;
  } else {
    desc = `A balanced ${req.trainingDays}-day program designed to maintain your current physique `;
    desc += `while improving overall fitness markers. Perfect for busy schedules `;
    desc += `who want to stay in shape without extreme commitments.`;
  }
  
  return desc;
}

function generateWeeklySchedule(
  days: number, 
  _goal: string, 
  _experience: string,
  volumeMult: number,
  intensity: { reps: string; sets: number; cardio: boolean }
): AIWorkoutDay[] {
  
  const baseSets = Math.round(intensity.sets * volumeMult);
  
  // Exercise database with AI-enhanced details
  const exercises = {
    chest: [
      { name: 'Bench Press', sets: baseSets, reps: intensity.reps, rest: '90s', tips: 'Keep shoulder blades retracted' },
      { name: 'Incline Dumbbell Press', sets: baseSets - 1, reps: intensity.reps, rest: '75s', tips: '30-degree incline for upper chest' },
      { name: 'Cable Flyes', sets: baseSets - 1, reps: '12-15', rest: '60s', tips: 'Squeeze at peak contraction' }
    ],
    back: [
      { name: 'Deadlift', sets: baseSets, reps: '5-8', rest: '3min', tips: 'Keep bar close to body' },
      { name: 'Pull-ups', sets: baseSets, reps: '8-12', rest: '90s', tips: 'Full range of motion' },
      { name: 'Barbell Row', sets: baseSets, reps: intensity.reps, rest: '90s', tips: 'Pull to lower chest' }
    ],
    legs: [
      { name: 'Squat', sets: baseSets + 1, reps: intensity.reps, rest: '2min', tips: 'Break parallel for full activation' },
      { name: 'Romanian Deadlift', sets: baseSets, reps: '10-12', rest: '90s', tips: 'Feel the hamstring stretch' },
      { name: 'Leg Press', sets: baseSets, reps: '12-15', rest: '90s', tips: 'Do not lock knees at top' }
    ],
    shoulders: [
      { name: 'Overhead Press', sets: baseSets, reps: intensity.reps, rest: '90s', tips: 'Brace core throughout' },
      { name: 'Lateral Raises', sets: baseSets, reps: '12-15', rest: '60s', tips: 'Lead with elbows, not hands' },
      { name: 'Face Pulls', sets: baseSets - 1, reps: '15-20', rest: '45s', tips: 'External rotation at end' }
    ],
    arms: [
      { name: 'Barbell Curls', sets: baseSets - 1, reps: '10-12', rest: '60s', tips: 'No swinging, strict form' },
      { name: 'Tricep Dips', sets: baseSets - 1, reps: '10-12', rest: '60s', tips: 'Lean forward for chest focus' },
      { name: 'Hammer Curls', sets: baseSets - 1, reps: '12-15', rest: '60s', tips: 'Neutral grip throughout' }
    ]
  };
  
  const warmup = ['5 min light cardio', 'Dynamic stretching', 'Movement-specific warmups'];
  const cooldown = ['Static stretching', 'Foam rolling', 'Deep breathing'];
  
  // Generate schedule based on training days
  if (days === 3) {
    return [
      {
        day: 1,
        focus: 'Full Body A - Push Focus',
        exercises: [...exercises.chest.slice(0, 2), exercises.shoulders[0], exercises.legs[0]],
        warmup, cooldown
      },
      { day: 2, focus: 'Rest & Recovery', exercises: [], warmup: [], cooldown: [] },
      {
        day: 3,
        focus: 'Full Body B - Pull Focus',
        exercises: [...exercises.back.slice(0, 2), exercises.arms[0], exercises.legs[1]],
        warmup, cooldown
      },
      { day: 4, focus: 'Active Recovery', exercises: [], warmup: [], cooldown: [] },
      {
        day: 5,
        focus: 'Full Body C - Leg Focus',
        exercises: [exercises.legs[0], exercises.legs[1], exercises.legs[2], exercises.shoulders[1]],
        warmup, cooldown
      },
      { day: 6, focus: 'Rest Day', exercises: [], warmup: [], cooldown: [] },
      { day: 7, focus: 'Complete Rest', exercises: [], warmup: [], cooldown: [] }
    ];
  } else if (days === 4) {
    return [
      {
        day: 1,
        focus: 'Upper Body - Push',
        exercises: [...exercises.chest, exercises.shoulders[0], exercises.arms[1]],
        warmup, cooldown
      },
      {
        day: 2,
        focus: 'Lower Body',
        exercises: [...exercises.legs, { name: 'Calf Raises', sets: 4, reps: '15-20', rest: '45s', tips: 'Full stretch at bottom' }],
        warmup, cooldown
      },
      { day: 3, focus: 'Rest', exercises: [], warmup: [], cooldown: [] },
      {
        day: 4,
        focus: 'Upper Body - Pull',
        exercises: [...exercises.back, exercises.arms[0], exercises.arms[2]],
        warmup, cooldown
      },
      {
        day: 5,
        focus: 'Lower Body & Core',
        exercises: [exercises.legs[0], exercises.legs[1], { name: 'Planks', sets: 3, reps: '45-60s', rest: '60s', tips: 'Keep body in straight line' }],
        warmup, cooldown
      },
      { day: 6, focus: 'Active Recovery', exercises: [], warmup: [], cooldown: [] },
      { day: 7, focus: 'Rest', exercises: [], warmup: [], cooldown: [] }
    ];
  } else if (days === 5) {
    return [
      {
        day: 1,
        focus: 'Chest & Triceps',
        exercises: [...exercises.chest, exercises.arms[1], { name: 'Tricep Pushdowns', sets: 3, reps: '12-15', rest: '60s', tips: 'Keep elbows tucked' }],
        warmup, cooldown
      },
      {
        day: 2,
        focus: 'Back & Biceps',
        exercises: [...exercises.back, ...exercises.arms.slice(0, 2)],
        warmup, cooldown
      },
      {
        day: 3,
        focus: 'Legs',
        exercises: [...exercises.legs, { name: 'Leg Curls', sets: 3, reps: '12-15', rest: '60s', tips: 'Control the negative' }],
        warmup, cooldown
      },
      { day: 4, focus: 'Rest', exercises: [], warmup: [], cooldown: [] },
      {
        day: 5,
        focus: 'Shoulders & Abs',
        exercises: [...exercises.shoulders, { name: 'Hanging Leg Raises', sets: 3, reps: '12-15', rest: '60s', tips: 'No swinging' }],
        warmup, cooldown
      },
      {
        day: 6,
        focus: 'Arms & Weak Points',
        exercises: [...exercises.arms, exercises.chest[2], exercises.back[2]],
        warmup, cooldown
      },
      { day: 7, focus: 'Rest', exercises: [], warmup: [], cooldown: [] }
    ];
  } else {
    // 6 days - Push/Pull/Legs twice
    return [
      {
        day: 1,
        focus: 'Push A - Chest Focus',
        exercises: [exercises.chest[0], exercises.chest[1], exercises.shoulders[0], exercises.arms[1]],
        warmup, cooldown
      },
      {
        day: 2,
        focus: 'Pull A - Width Focus',
        exercises: [exercises.back[1], exercises.back[2], exercises.arms[0], exercises.shoulders[2]],
        warmup, cooldown
      },
      {
        day: 3,
        focus: 'Legs A - Quad Focus',
        exercises: [exercises.legs[0], exercises.legs[2], { name: 'Leg Extensions', sets: 3, reps: '15-20', rest: '60s', tips: 'Squeeze quads at top' }],
        warmup, cooldown
      },
      {
        day: 4,
        focus: 'Push B - Shoulder Focus',
        exercises: [exercises.shoulders[0], exercises.chest[2], exercises.shoulders[1], exercises.arms[1]],
        warmup, cooldown
      },
      {
        day: 5,
        focus: 'Pull B - Thickness Focus',
        exercises: [exercises.back[0], exercises.back[2], exercises.arms[2], exercises.shoulders[2]],
        warmup, cooldown
      },
      {
        day: 6,
        focus: 'Legs B - Hamstring Focus',
        exercises: [exercises.legs[1], exercises.legs[0], { name: 'Leg Curls', sets: 4, reps: '12-15', rest: '60s', tips: 'Full contraction' }],
        warmup, cooldown
      },
      { day: 7, focus: 'Rest & Recovery', exercises: [], warmup: [], cooldown: [] }
    ];
  }
}

function generateNutritionTips(goal: string, bmi: number, _gender: string): string[] {
  const tips = [];
  
  if (goal === 'loseWeight') {
    tips.push('Create a 300-500 calorie deficit for sustainable fat loss');
    tips.push('Prioritize protein intake: 2g per kg of bodyweight');
    tips.push('Eat plenty of fiber-rich vegetables to stay full');
    tips.push('Limit processed sugars and refined carbohydrates');
    tips.push('Drink at least 3 liters of water daily');
  } else if (goal === 'buildMuscle') {
    tips.push('Eat in a slight surplus: +300 calories above maintenance');
    tips.push('Protein is crucial: 2.2g per kg of bodyweight');
    tips.push('Time carbs around workouts for optimal performance');
    tips.push('Include healthy fats for hormone production');
    tips.push('Consider creatine monohydrate supplementation');
  } else {
    tips.push('Eat at maintenance calories');
    tips.push('Maintain protein at 1.8g per kg of bodyweight');
    tips.push('Focus on nutrient-dense whole foods');
    tips.push('Stay hydrated: minimum 2.5 liters daily');
    tips.push('Practice mindful eating habits');
  }
  
  if (bmi > 30) {
    tips.push('Consider consulting a doctor before starting intense training');
  }
  
  return tips;
}

function generateProgressionStrategy(experience: string, _goal: string): string {
  if (experience === 'beginner') {
    return 'Focus on mastering form first. Add 2.5kg to compound lifts when you can complete all sets with good form. Progress weekly if possible.';
  } else if (experience === 'intermediate') {
    return 'Use double progression: first increase reps within range, then increase weight. Deload every 4-6 weeks. Track your lifts consistently.';
  } else {
    return 'Implement periodization: 3 weeks intensity, 1 week deload. Use advanced techniques like drop sets and rest-pause on isolation movements.';
  }
}

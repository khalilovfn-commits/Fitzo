import { useState, useCallback } from 'react';
import { translations, type Language } from '@/i18n/translations';

export function useLanguage() {
  const [language, setLanguageState] = useState<Language>('tr');
  
  const setLanguage = useCallback((lang: Language) => {
    setLanguageState(lang);
    localStorage.setItem('fitzo-language', lang);
  }, []);
  
  // Load saved language on mount
  const loadSavedLanguage = useCallback(() => {
    const saved = localStorage.getItem('fitzo-language') as Language;
    if (saved && translations[saved]) {
      setLanguageState(saved);
    }
  }, []);
  
  const t = translations[language];
  
  return { language, setLanguage, t, loadSavedLanguage };
}

export type Language = 'ru' | 'tr' | 'en' | 'az';

export const translations = {
  ru: {
    // Header
    appName: 'Fitzo',
    tagline: 'Ваш персональный фитнес-помощник',
    
    // Language Selector
    selectLanguage: 'Выберите язык',
    
    // User Info Form
    yourInfo: 'Ваша информация',
    height: 'Рост (см)',
    weight: 'Вес (кг)',
    age: 'Возраст',
    gender: 'Пол',
    male: 'Мужской',
    female: 'Женский',
    goal: 'Цель',
    loseWeight: 'Похудеть',
    buildMuscle: 'Набрать мышечную массу',
    maintain: 'Поддерживать форму',
    experience: 'Опыт',
    beginner: 'Начинающий',
    intermediate: 'Средний',
    advanced: 'Продвинутый',
    
    // Training Frequency
    trainingFrequency: 'Частота тренировок',
    daysPerWeek: 'дней в неделю',
    selectDays: 'Выберите количество дней',
    
    // Buttons
    generateProgram: 'Создать программу',
    reset: 'Сбросить',
    
    // Results
    yourProgram: 'Ваша персональная программа',
    bmi: 'ИМТ',
    bmiUnderweight: 'Недостаточный вес',
    bmiNormal: 'Нормальный вес',
    bmiOverweight: 'Избыточный вес',
    bmiObese: 'Ожирение',
    recommendedCalories: 'Рекомендуемое потребление калорий',
    perDay: 'в день',
    
    // Program Headers
    weeklySchedule: 'Расписание на неделю',
    day: 'День',
    restDay: 'Выходной',
    exercises: 'Упражнения',
    sets: 'подходы',
    reps: 'повторы',
    
    // Footer
    poweredBy: 'Работает на',
    
    // Validation
    pleaseFillAll: 'Пожалуйста, заполните все поля',
    invalidHeight: 'Рост должен быть от 100 до 250 см',
    invalidWeight: 'Вес должен быть от 30 до 200 кг',
    invalidAge: 'Возраст должен быть от 16 до 80 лет',
  },
  
  tr: {
    // Header
    appName: 'Fitzo',
    tagline: 'Kişisel Fitness Asistanınız',
    
    // Language Selector
    selectLanguage: 'Dil Seçin',
    
    // User Info Form
    yourInfo: 'Bilgileriniz',
    height: 'Boy (cm)',
    weight: 'Kilo (kg)',
    age: 'Yaş',
    gender: 'Cinsiyet',
    male: 'Erkek',
    female: 'Kadın',
    goal: 'Hedef',
    loseWeight: 'Kilo Vermek',
    buildMuscle: 'Kas Yapmak',
    maintain: 'Form Korumak',
    experience: 'Deneyim',
    beginner: 'Başlangıç',
    intermediate: 'Orta Seviye',
    advanced: 'İleri Seviye',
    
    // Training Frequency
    trainingFrequency: 'Antrenman Sıklığı',
    daysPerWeek: 'gün/hafta',
    selectDays: 'Gün sayısı seçin',
    
    // Buttons
    generateProgram: 'Program Oluştur',
    reset: 'Sıfırla',
    
    // Results
    yourProgram: 'Kişisel Programınız',
    bmi: 'VKİ',
    bmiUnderweight: 'Zayıf',
    bmiNormal: 'Normal',
    bmiOverweight: 'Fazla Kilolu',
    bmiObese: 'Obez',
    recommendedCalories: 'Önerilen Kalori Alımı',
    perDay: 'günlük',
    
    // Program Headers
    weeklySchedule: 'Haftalık Program',
    day: 'Gün',
    restDay: 'Dinlenme Günü',
    exercises: 'Egzersizler',
    sets: 'set',
    reps: 'tekrar',
    
    // Footer
    poweredBy: 'Powered by',
    
    // Validation
    pleaseFillAll: 'Lütfen tüm alanları doldurun',
    invalidHeight: 'Boy 100-250 cm arasında olmalı',
    invalidWeight: 'Kilo 30-200 kg arasında olmalı',
    invalidAge: 'Yaş 16-80 arasında olmalı',
  },
  
  en: {
    // Header
    appName: 'Fitzo',
    tagline: 'Your Personal Fitness Assistant',
    
    // Language Selector
    selectLanguage: 'Select Language',
    
    // User Info Form
    yourInfo: 'Your Information',
    height: 'Height (cm)',
    weight: 'Weight (kg)',
    age: 'Age',
    gender: 'Gender',
    male: 'Male',
    female: 'Female',
    goal: 'Goal',
    loseWeight: 'Lose Weight',
    buildMuscle: 'Build Muscle',
    maintain: 'Maintain Fitness',
    experience: 'Experience',
    beginner: 'Beginner',
    intermediate: 'Intermediate',
    advanced: 'Advanced',
    
    // Training Frequency
    trainingFrequency: 'Training Frequency',
    daysPerWeek: 'days/week',
    selectDays: 'Select number of days',
    
    // Buttons
    generateProgram: 'Generate Program',
    reset: 'Reset',
    
    // Results
    yourProgram: 'Your Personal Program',
    bmi: 'BMI',
    bmiUnderweight: 'Underweight',
    bmiNormal: 'Normal',
    bmiOverweight: 'Overweight',
    bmiObese: 'Obese',
    recommendedCalories: 'Recommended Calorie Intake',
    perDay: 'per day',
    
    // Program Headers
    weeklySchedule: 'Weekly Schedule',
    day: 'Day',
    restDay: 'Rest Day',
    exercises: 'Exercises',
    sets: 'sets',
    reps: 'reps',
    
    // Footer
    poweredBy: 'Powered by',
    
    // Validation
    pleaseFillAll: 'Please fill in all fields',
    invalidHeight: 'Height must be between 100-250 cm',
    invalidWeight: 'Weight must be between 30-200 kg',
    invalidAge: 'Age must be between 16-80',
  },
  
  az: {
    // Header
    appName: 'Fitzo',
    tagline: 'Şəxsi Fitness Köməkçiniz',
    
    // Language Selector
    selectLanguage: 'Dil Seçin',
    
    // User Info Form
    yourInfo: 'Məlumatlarınız',
    height: 'Boy (sm)',
    weight: 'Çəki (kq)',
    age: 'Yaş',
    gender: 'Cins',
    male: 'Kişi',
    female: 'Qadın',
    goal: 'Məqsəd',
    loseWeight: 'Çəki Atmaq',
    buildMuscle: 'Əzələ Yığmaq',
    maintain: 'Forma Qalmaq',
    experience: 'Təcrübə',
    beginner: 'Başlanğıc',
    intermediate: 'Orta Səviyyə',
    advanced: 'İrəli Səviyyə',
    
    // Training Frequency
    trainingFrequency: 'Məşq Tezliyi',
    daysPerWeek: 'gün/həftə',
    selectDays: 'Gün sayını seçin',
    
    // Buttons
    generateProgram: 'Program Yarat',
    reset: 'Sıfırla',
    
    // Results
    yourProgram: 'Şəxsi Proqramınız',
    bmi: 'BKT',
    bmiUnderweight: 'Arıq',
    bmiNormal: 'Normal',
    bmiOverweight: 'Artıq Çəki',
    bmiObese: 'Piylənmə',
    recommendedCalories: 'Tövsiyə Olunan Kalori',
    perDay: 'gündəlik',
    
    // Program Headers
    weeklySchedule: 'Həftəlik Cədvəl',
    day: 'Gün',
    restDay: 'Istirahət Günü',
    exercises: 'Məşqlər',
    sets: 'set',
    reps: 'təkrar',
    
    // Footer
    poweredBy: 'Powered by',
    
    // Validation
    pleaseFillAll: 'Zəhmət olmasa, bütün sahələri doldurun',
    invalidHeight: 'Boy 100-250 sm arasında olmalıdır',
    invalidWeight: 'Çəki 30-200 kq arasında olmalıdır',
    invalidAge: 'Yaş 16-80 arasında olmalıdır',
  }
};

export type Translations = typeof translations.en;

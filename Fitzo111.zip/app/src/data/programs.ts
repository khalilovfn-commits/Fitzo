export interface Exercise {
  name: {
    ru: string;
    tr: string;
    en: string;
    az: string;
  };
  sets: number;
  reps: string;
}

export interface WorkoutDay {
  day: number;
  isRestDay: boolean;
  focus?: {
    ru: string;
    tr: string;
    en: string;
    az: string;
  };
  exercises?: Exercise[];
}

export interface UserProfile {
  height: number;
  weight: number;
  age: number;
  gender: 'male' | 'female';
  goal: 'loseWeight' | 'buildMuscle' | 'maintain';
  experience: 'beginner' | 'intermediate' | 'advanced';
  trainingDays: 3 | 4 | 5 | 6;
}

// Exercise database with multilingual names
const exercises = {
  // Chest exercises
  benchPress: {
    name: { ru: 'Жим штанги лежа', tr: 'Bench Press', en: 'Bench Press', az: 'Bench Press' },
    sets: 4, reps: '8-12'
  },
  inclineBenchPress: {
    name: { ru: 'Жим штанги на наклонной скамье', tr: 'Eğimli Bench Press', en: 'Incline Bench Press', az: 'Maili Bench Press' },
    sets: 4, reps: '8-12'
  },
  dumbbellFlyes: {
    name: { ru: 'Разведение гантелей', tr: 'Dumbbell Fly', en: 'Dumbbell Flyes', az: 'Dumbbell Fly' },
    sets: 3, reps: '12-15'
  },
  pushUps: {
    name: { ru: 'Отжимания', tr: 'Şınav', en: 'Push-ups', az: 'Şınav' },
    sets: 3, reps: '15-20'
  },
  chestPressMachine: {
    name: { ru: 'Жим в тренажере', tr: 'Göğüs Press Makinesi', en: 'Chest Press Machine', az: 'Sinə Press Aparatı' },
    sets: 3, reps: '10-12'
  },
  
  // Back exercises
  pullUps: {
    name: { ru: 'Подтягивания', tr: 'Barfiks', en: 'Pull-ups', az: 'Barfiks' },
    sets: 4, reps: '8-12'
  },
  latPulldown: {
    name: { ru: 'Тяга верхнего блока', tr: 'Lat Pulldown', en: 'Lat Pulldown', az: 'Lat Pulldown' },
    sets: 4, reps: '10-12'
  },
  barbellRow: {
    name: { ru: 'Тяга штанги в наклоне', tr: 'Barbell Row', en: 'Barbell Row', az: 'Barbell Row' },
    sets: 4, reps: '8-12'
  },
  seatedCableRow: {
    name: { ru: 'Тяга горизонтального блока', tr: 'Cable Row', en: 'Seated Cable Row', az: 'Cable Row' },
    sets: 3, reps: '10-12'
  },
  deadlift: {
    name: { ru: 'Становая тяга', tr: 'Deadlift', en: 'Deadlift', az: 'Deadlift' },
    sets: 4, reps: '6-10'
  },
  
  // Shoulder exercises
  overheadPress: {
    name: { ru: 'Жим штанги стоя', tr: 'Overhead Press', en: 'Overhead Press', az: 'Overhead Press' },
    sets: 4, reps: '8-12'
  },
  lateralRaises: {
    name: { ru: 'Разведение гантелей в стороны', tr: 'Lateral Raise', en: 'Lateral Raises', az: 'Lateral Raise' },
    sets: 3, reps: '12-15'
  },
  frontRaises: {
    name: { ru: 'Подъем гантелей перед собой', tr: 'Front Raise', en: 'Front Raises', az: 'Front Raise' },
    sets: 3, reps: '12-15'
  },
  facePulls: {
    name: { ru: 'Тяга к лицу', tr: 'Face Pull', en: 'Face Pulls', az: 'Face Pull' },
    sets: 3, reps: '15-20'
  },
  
  // Arm exercises
  bicepCurls: {
    name: { ru: 'Сгибание рук с гантелями', tr: 'Biceps Curl', en: 'Bicep Curls', az: 'Biceps Curl' },
    sets: 3, reps: '10-12'
  },
  hammerCurls: {
    name: { ru: 'Молотковые сгибания', tr: 'Hammer Curl', en: 'Hammer Curls', az: 'Hammer Curl' },
    sets: 3, reps: '10-12'
  },
  tricepPushdowns: {
    name: { ru: 'Разгибание рук на блоке', tr: 'Triceps Pushdown', en: 'Tricep Pushdowns', az: 'Triceps Pushdown' },
    sets: 3, reps: '12-15'
  },
  skullcrushers: {
    name: { ru: 'Французский жим', tr: 'Skullcrusher', en: 'Skullcrushers', az: 'Skullcrusher' },
    sets: 3, reps: '10-12'
  },
  
  // Leg exercises
  squats: {
    name: { ru: 'Приседания со штангой', tr: 'Squat', en: 'Squats', az: 'Squat' },
    sets: 4, reps: '8-12'
  },
  legPress: {
    name: { ru: 'Жим ногами', tr: 'Leg Press', en: 'Leg Press', az: 'Leg Press' },
    sets: 4, reps: '10-15'
  },
  lunges: {
    name: { ru: 'Выпады с гантелями', tr: 'Lunge', en: 'Lunges', az: 'Lunge' },
    sets: 3, reps: '12-15'
  },
  legCurls: {
    name: { ru: 'Сгибание ног', tr: 'Leg Curl', en: 'Leg Curls', az: 'Leg Curl' },
    sets: 3, reps: '12-15'
  },
  legExtensions: {
    name: { ru: 'Разгибание ног', tr: 'Leg Extension', en: 'Leg Extensions', az: 'Leg Extension' },
    sets: 3, reps: '15-20'
  },
  calfRaises: {
    name: { ru: 'Подъемы на носки', tr: 'Calf Raise', en: 'Calf Raises', az: 'Calf Raise' },
    sets: 4, reps: '15-20'
  },
  romanianDeadlift: {
    name: { ru: 'Румынская тяга', tr: 'Romen Deadlift', en: 'Romanian Deadlift', az: 'Romen Deadlift' },
    sets: 4, reps: '10-12'
  },
  
  // Core exercises
  planks: {
    name: { ru: 'Планка', tr: 'Plank', en: 'Planks', az: 'Plank' },
    sets: 3, reps: '45-60 sn'
  },
  crunches: {
    name: { ru: 'Скручивания', tr: 'Crunch', en: 'Crunches', az: 'Crunch' },
    sets: 3, reps: '20-25'
  },
  legRaises: {
    name: { ru: 'Подъем ног', tr: 'Leg Raise', en: 'Leg Raises', az: 'Leg Raise' },
    sets: 3, reps: '15-20'
  },
  russianTwists: {
    name: { ru: 'Русские скручивания', tr: 'Russian Twist', en: 'Russian Twists', az: 'Russian Twist' },
    sets: 3, reps: '20-30'
  },
  
  // Cardio
  running: {
    name: { ru: 'Бег', tr: 'Koşu', en: 'Running', az: 'Qaçış' },
    sets: 1, reps: '20-30 min'
  },
  cycling: {
    name: { ru: 'Велосипед', tr: 'Bisiklet', en: 'Cycling', az: 'Velosiped' },
    sets: 1, reps: '20-30 min'
  },
  hiit: {
    name: { ru: 'ВИИТ', tr: 'HIIT', en: 'HIIT', az: 'HIIT' },
    sets: 1, reps: '15-20 min'
  },
  jumpRope: {
    name: { ru: 'Прыжки со скакалкой', tr: 'İp Atlama', en: 'Jump Rope', az: 'İp Atlama' },
    sets: 1, reps: '10-15 min'
  }
};

// Program templates for different training frequencies
export function generateProgram(profile: UserProfile): WorkoutDay[] {
  const { trainingDays, goal } = profile;
  
  // Adjust sets and reps based on goal
  const adjustForGoal = (ex: typeof exercises[keyof typeof exercises]) => {
    let adjustedSets = ex.sets;
    let adjustedReps = ex.reps;
    
    if (goal === 'loseWeight') {
      // Higher reps for fat loss
      if (ex.reps.includes('-')) {
        const [min, max] = ex.reps.split('-').map(x => parseInt(x));
        adjustedReps = `${Math.round(min * 1.2)}-${Math.round(max * 1.2)}`;
      }
    } else if (goal === 'buildMuscle') {
      // Moderate reps for hypertrophy
      adjustedSets = Math.min(ex.sets + 1, 5);
    }
    
    return { ...ex, sets: adjustedSets, reps: adjustedReps };
  };
  
  // Create exercise list helper
  const ex = (key: keyof typeof exercises) => adjustForGoal(exercises[key]);
  
  // 3-day split (Full Body)
  if (trainingDays === 3) {
    return [
      {
        day: 1,
        isRestDay: false,
        focus: { ru: 'Все тело A', tr: 'Tam Vücut A', en: 'Full Body A', az: 'Tam Bədən A' },
        exercises: [
          ex('squats'), ex('benchPress'), ex('barbellRow'), 
          ex('overheadPress'), ex('bicepCurls'), ex('planks')
        ]
      },
      { day: 2, isRestDay: true },
      {
        day: 3,
        isRestDay: false,
        focus: { ru: 'Все тело B', tr: 'Tam Vücut B', en: 'Full Body B', az: 'Tam Bədən B' },
        exercises: [
          ex('deadlift'), ex('inclineBenchPress'), ex('latPulldown'),
          ex('lateralRaises'), ex('tricepPushdowns'), ex('legRaises')
        ]
      },
      { day: 4, isRestDay: true },
      {
        day: 5,
        isRestDay: false,
        focus: { ru: 'Все тело C', tr: 'Tam Vücut C', en: 'Full Body C', az: 'Tam Bədən C' },
        exercises: [
          ex('legPress'), ex('dumbbellFlyes'), ex('seatedCableRow'),
          ex('frontRaises'), ex('hammerCurls'), ex('crunches')
        ]
      },
      { day: 6, isRestDay: true },
      { day: 7, isRestDay: true }
    ];
  }
  
  // 4-day split (Upper/Lower)
  if (trainingDays === 4) {
    return [
      {
        day: 1,
        isRestDay: false,
        focus: { ru: 'Верх A', tr: 'Üst Vücut A', en: 'Upper A', az: 'Üst Bədən A' },
        exercises: [
          ex('benchPress'), ex('latPulldown'), ex('overheadPress'),
          ex('barbellRow'), ex('bicepCurls'), ex('tricepPushdowns')
        ]
      },
      {
        day: 2,
        isRestDay: false,
        focus: { ru: 'Низ A', tr: 'Alt Vücut A', en: 'Lower A', az: 'Alt Bədən A' },
        exercises: [
          ex('squats'), ex('romanianDeadlift'), ex('legPress'),
          ex('legCurls'), ex('legExtensions'), ex('calfRaises')
        ]
      },
      { day: 3, isRestDay: true },
      {
        day: 4,
        isRestDay: false,
        focus: { ru: 'Верх B', tr: 'Üst Vücut B', en: 'Upper B', az: 'Üst Bədən B' },
        exercises: [
          ex('inclineBenchPress'), ex('pullUps'), ex('lateralRaises'),
          ex('seatedCableRow'), ex('hammerCurls'), ex('skullcrushers')
        ]
      },
      {
        day: 5,
        isRestDay: false,
        focus: { ru: 'Низ B', tr: 'Alt Vücut B', en: 'Lower B', az: 'Alt Bədən B' },
        exercises: [
          ex('deadlift'), ex('lunges'), ex('legPress'),
          ex('legCurls'), ex('calfRaises'), ex('planks')
        ]
      },
      { day: 6, isRestDay: true },
      { day: 7, isRestDay: true }
    ];
  }
  
  // 5-day split (Push/Pull/Legs + Upper/Lower)
  if (trainingDays === 5) {
    return [
      {
        day: 1,
        isRestDay: false,
        focus: { ru: 'Грудь + Трицепс', tr: 'Göğüs + Triceps', en: 'Chest + Triceps', az: 'Sinə + Triceps' },
        exercises: [
          ex('benchPress'), ex('inclineBenchPress'), ex('dumbbellFlyes'),
          ex('chestPressMachine'), ex('tricepPushdowns'), ex('skullcrushers')
        ]
      },
      {
        day: 2,
        isRestDay: false,
        focus: { ru: 'Спина + Бицепс', tr: 'Sırt + Biceps', en: 'Back + Biceps', az: 'Arxa + Biceps' },
        exercises: [
          ex('pullUps'), ex('latPulldown'), ex('barbellRow'),
          ex('seatedCableRow'), ex('bicepCurls'), ex('hammerCurls')
        ]
      },
      {
        day: 3,
        isRestDay: false,
        focus: { ru: 'Ноги', tr: 'Bacak', en: 'Legs', az: 'Ayaqlar' },
        exercises: [
          ex('squats'), ex('legPress'), ex('romanianDeadlift'),
          ex('legCurls'), ex('legExtensions'), ex('calfRaises')
        ]
      },
      { day: 4, isRestDay: true },
      {
        day: 5,
        isRestDay: false,
        focus: { ru: 'Плечи + Предплечья', tr: 'Omuz + Ön Kol', en: 'Shoulders + Forearms', az: 'Çiyn + Qol' },
        exercises: [
          ex('overheadPress'), ex('lateralRaises'), ex('frontRaises'),
          ex('facePulls'), ex('bicepCurls'), ex('planks')
        ]
      },
      {
        day: 6,
        isRestDay: false,
        focus: { ru: 'Все тело + Кардио', tr: 'Tam Vücut + Kardiyo', en: 'Full Body + Cardio', az: 'Tam Bədən + Kardio' },
        exercises: [
          ex('deadlift'), ex('pushUps'), ex('lunges'),
          ex('latPulldown'), ex('hiit'), ex('crunches')
        ]
      },
      { day: 7, isRestDay: true }
    ];
  }
  
  // 6-day split (Push/Pull/Legs twice a week)
  return [
    {
      day: 1,
      isRestDay: false,
      focus: { ru: 'Жим A', tr: 'Push A', en: 'Push A', az: 'Push A' },
      exercises: [
        ex('benchPress'), ex('overheadPress'), ex('inclineBenchPress'),
        ex('lateralRaises'), ex('tricepPushdowns'), ex('skullcrushers')
      ]
    },
    {
      day: 2,
      isRestDay: false,
      focus: { ru: 'Тяга A', tr: 'Pull A', en: 'Pull A', az: 'Pull A' },
      exercises: [
        ex('deadlift'), ex('pullUps'), ex('barbellRow'),
        ex('facePulls'), ex('bicepCurls'), ex('hammerCurls')
      ]
    },
    {
      day: 3,
      isRestDay: false,
      focus: { ru: 'Ноги A', tr: 'Legs A', en: 'Legs A', az: 'Ayaqlar A' },
      exercises: [
        ex('squats'), ex('legPress'), ex('romanianDeadlift'),
        ex('legCurls'), ex('legExtensions'), ex('calfRaises')
      ]
    },
    {
      day: 4,
      isRestDay: false,
      focus: { ru: 'Жим B', tr: 'Push B', en: 'Push B', az: 'Push B' },
      exercises: [
        ex('dumbbellFlyes'), ex('chestPressMachine'), ex('frontRaises'),
        ex('overheadPress'), ex('tricepPushdowns'), ex('pushUps')
      ]
    },
    {
      day: 5,
      isRestDay: false,
      focus: { ru: 'Тяга B', tr: 'Pull B', en: 'Pull B', az: 'Pull B' },
      exercises: [
        ex('latPulldown'), ex('seatedCableRow'), ex('romanianDeadlift'),
        ex('barbellRow'), ex('bicepCurls'), ex('facePulls')
      ]
    },
    {
      day: 6,
      isRestDay: false,
      focus: { ru: 'Ноги B', tr: 'Legs B', en: 'Legs B', az: 'Ayaqlar B' },
      exercises: [
        ex('lunges'), ex('legPress'), ex('squats'),
        ex('calfRaises'), ex('legCurls'), ex('planks')
      ]
    },
    { day: 7, isRestDay: true }
  ];
}

// Calculate BMI
export function calculateBMI(height: number, weight: number): { value: number; category: string } {
  const heightInMeters = height / 100;
  const bmi = weight / (heightInMeters * heightInMeters);
  const roundedBMI = Math.round(bmi * 10) / 10;
  
  let category = '';
  if (bmi < 18.5) category = 'underweight';
  else if (bmi < 25) category = 'normal';
  else if (bmi < 30) category = 'overweight';
  else category = 'obese';
  
  return { value: roundedBMI, category };
}

// Calculate recommended calories
export function calculateCalories(profile: UserProfile): number {
  const { height, weight, age, gender, goal, trainingDays } = profile;
  
  // Mifflin-St Jeor Equation
  let bmr = 10 * weight + 6.25 * height - 5 * age;
  bmr += gender === 'male' ? 5 : -161;
  
  // Activity multiplier based on training days
  const activityMultipliers: Record<number, number> = {
    3: 1.375,
    4: 1.465,
    5: 1.55,
    6: 1.725
  };
  
  let tdee = Math.round(bmr * activityMultipliers[trainingDays]);
  
  // Adjust for goal
  if (goal === 'loseWeight') tdee -= 500;
  else if (goal === 'buildMuscle') tdee += 300;
  
  return tdee;
}

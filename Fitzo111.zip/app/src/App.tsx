import { useState, useEffect } from 'react';
import { useLanguage } from '@/hooks/useLanguage';
import type { Language } from '@/i18n/translations';
import { generateProgram, calculateBMI, calculateCalories, type WorkoutDay, type UserProfile } from '@/data/programs';
import { ProfileUpload } from '@/components/ProfileUpload';
import { AIChatbot } from '@/components/AIChatbot';
import { AIProgramGenerator } from '@/components/AIProgram';
import { 
  Dumbbell, 
  Globe, 
  User, 
  Target, 
  TrendingUp, 
  Calendar, 
  Flame,
  RotateCcw,
  ChevronDown,
  Check,
  Activity,
  Scale,
  Ruler,
  Clock,
  Sparkles,
  Bot
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

// Extended translations
const extendedTranslations = {
  ru: {
    addPhoto: 'Добавить фото',
    remove: 'Удалить',
    dragDrop: 'Перетащите фото или нажмите',
    aiProgram: 'AI Программа',
    standardProgram: 'Стандартная программа',
    aiAssistant: 'AI Ассистент',
    askAI: 'Спросить AI',
    profilePhoto: 'Фото профиля'
  },
  tr: {
    addPhoto: 'Fotoğraf Ekle',
    remove: 'Kaldır',
    dragDrop: 'Fotoğrafı sürükleyin veya tıklayın',
    aiProgram: 'AI Programı',
    standardProgram: 'Standart Program',
    aiAssistant: 'AI Asistan',
    askAI: 'AI\'ye Sor',
    profilePhoto: 'Profil Fotoğrafı'
  },
  en: {
    addPhoto: 'Add Photo',
    remove: 'Remove',
    dragDrop: 'Drag photo or click',
    aiProgram: 'AI Program',
    standardProgram: 'Standard Program',
    aiAssistant: 'AI Assistant',
    askAI: 'Ask AI',
    profilePhoto: 'Profile Photo'
  },
  az: {
    addPhoto: 'Şəkil Əlavə Et',
    remove: 'Sil',
    dragDrop: 'Şəkili sürükləyin və ya klikləyin',
    aiProgram: 'AI Proqramı',
    standardProgram: 'Standart Proqram',
    aiAssistant: 'AI Köməkçi',
    askAI: 'AI-yə Sor',
    profilePhoto: 'Profil Şəkli'
  }
};

function App() {
  const { language, setLanguage, t, loadSavedLanguage } = useLanguage();
  const [showProgram, setShowProgram] = useState(false);
  const [program, setProgram] = useState<WorkoutDay[]>([]);
  const [userStats, setUserStats] = useState<{ bmi: { value: number; category: string }; calories: number } | null>(null);
  const [profileImage, setProfileImage] = useState<string | null>(null);
  const [chatbotOpen, setChatbotOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<'standard' | 'ai'>('standard');
  
  // Form state
  const [height, setHeight] = useState('');
  const [weight, setWeight] = useState('');
  const [age, setAge] = useState('');
  const [gender, setGender] = useState<'male' | 'female'>('male');
  const [goal, setGoal] = useState<'loseWeight' | 'buildMuscle' | 'maintain'>('maintain');
  const [experience, setExperience] = useState<'beginner' | 'intermediate' | 'advanced'>('beginner');
  const [trainingDays, setTrainingDays] = useState<3 | 4 | 5 | 6>(3);
  
  // Language dropdown state
  const [langDropdownOpen, setLangDropdownOpen] = useState(false);
  
  useEffect(() => {
    loadSavedLanguage();
    // Load saved profile image
    const savedImage = localStorage.getItem('fitzo-profile-image');
    if (savedImage) {
      setProfileImage(savedImage);
    }
  }, [loadSavedLanguage]);
  
  const handleImageSelect = (imageUrl: string | null) => {
    setProfileImage(imageUrl);
    if (imageUrl) {
      localStorage.setItem('fitzo-profile-image', imageUrl);
    } else {
      localStorage.removeItem('fitzo-profile-image');
    }
  };
  
  const languages: { code: Language; name: string; flag: string }[] = [
    { code: 'ru', name: 'Русский', flag: '🇷🇺' },
    { code: 'tr', name: 'Türkçe', flag: '🇹🇷' },
    { code: 'en', name: 'English', flag: '🇬🇧' },
    { code: 'az', name: 'Azərbaycanca', flag: '🇦🇿' },
  ];
  
  const extT = extendedTranslations[language];
  
  const getUserProfile = (): UserProfile => {
    return {
      height: parseFloat(height) || 175,
      weight: parseFloat(weight) || 70,
      age: parseInt(age) || 25,
      gender,
      goal,
      experience,
      trainingDays
    };
  };
  
  const handleGenerateProgram = () => {
    // Validation
    const h = parseFloat(height);
    const w = parseFloat(weight);
    const a = parseInt(age);
    
    if (!height || !weight || !age) {
      toast.error(t.pleaseFillAll);
      return;
    }
    
    if (h < 100 || h > 250) {
      toast.error(t.invalidHeight);
      return;
    }
    
    if (w < 30 || w > 200) {
      toast.error(t.invalidWeight);
      return;
    }
    
    if (a < 16 || a > 80) {
      toast.error(t.invalidAge);
      return;
    }
    
    const profile: UserProfile = {
      height: h,
      weight: w,
      age: a,
      gender,
      goal,
      experience,
      trainingDays
    };
    
    const generatedProgram = generateProgram(profile);
    const bmi = calculateBMI(h, w);
    const calories = calculateCalories(profile);
    
    setProgram(generatedProgram);
    setUserStats({ bmi, calories });
    setShowProgram(true);
    
    toast.success(language === 'tr' ? 'Program oluşturuldu!' : 
                  language === 'ru' ? 'Программа создана!' :
                  language === 'az' ? 'Program yaradıldı!' : 'Program created!');
  };
  
  const handleReset = () => {
    setHeight('');
    setWeight('');
    setAge('');
    setGender('male');
    setGoal('maintain');
    setExperience('beginner');
    setTrainingDays(3);
    setShowProgram(false);
    setProgram([]);
    setUserStats(null);
    setActiveTab('standard');
  };
  
  const getBMICategoryText = (category: string) => {
    switch (category) {
      case 'underweight': return t.bmiUnderweight;
      case 'normal': return t.bmiNormal;
      case 'overweight': return t.bmiOverweight;
      case 'obese': return t.bmiObese;
      default: return '';
    }
  };
  
  const getBMIColor = (category: string) => {
    switch (category) {
      case 'underweight': return 'bg-yellow-500';
      case 'normal': return 'bg-green-500';
      case 'overweight': return 'bg-orange-500';
      case 'obese': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900">
      {/* Header */}
      <header className="sticky top-0 z-50 glass border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl gradient-primary flex items-center justify-center">
                <Dumbbell className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-white">{t.appName}</h1>
                <p className="text-xs text-indigo-300">{t.tagline}</p>
              </div>
            </div>
            
            <div className="flex items-center gap-3">
              {/* AI Assistant Button */}
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setChatbotOpen(!chatbotOpen)}
                className="text-indigo-400 hover:text-indigo-300 hover:bg-indigo-500/10 hidden sm:flex"
              >
                <Bot className="w-5 h-5 mr-2" />
                {extT.askAI}
              </Button>
              
              {/* Language Selector */}
              <div className="relative">
                <button
                  onClick={() => setLangDropdownOpen(!langDropdownOpen)}
                  className="flex items-center gap-2 px-4 py-2 rounded-lg bg-white/10 hover:bg-white/20 transition-colors text-white"
                >
                  <Globe className="w-4 h-4" />
                  <span>{languages.find(l => l.code === language)?.flag}</span>
                  <span className="hidden sm:inline">{languages.find(l => l.code === language)?.name}</span>
                  <ChevronDown className={`w-4 h-4 transition-transform ${langDropdownOpen ? 'rotate-180' : ''}`} />
                </button>
                
                {langDropdownOpen && (
                  <div className="absolute right-0 mt-2 w-48 rounded-xl bg-slate-800 border border-white/10 shadow-2xl overflow-hidden animate-fadeIn">
                    {languages.map((lang) => (
                      <button
                        key={lang.code}
                        onClick={() => {
                          setLanguage(lang.code);
                          setLangDropdownOpen(false);
                        }}
                        className={`w-full flex items-center gap-3 px-4 py-3 hover:bg-white/10 transition-colors text-left ${
                          language === lang.code ? 'bg-indigo-600/30' : ''
                        }`}
                      >
                        <span className="text-lg">{lang.flag}</span>
                        <span className="text-white">{lang.name}</span>
                        {language === lang.code && <Check className="w-4 h-4 text-indigo-400 ml-auto" />}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Hero Section */}
        {!showProgram && (
          <div className="text-center mb-12 animate-fadeIn">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-indigo-500/20 border border-indigo-500/30 mb-6">
              <Sparkles className="w-4 h-4 text-indigo-400" />
              <span className="text-indigo-300 text-sm">
                {language === 'tr' ? 'AI Destekli Fitness' : 
                 language === 'ru' ? 'Фитнес с AI' :
                 language === 'az' ? 'AI Dəstəkli Fitness' : 'AI Powered Fitness'}
              </span>
            </div>
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
              {language === 'tr' ? 'Hedeflerine Ulaş' : 
               language === 'ru' ? 'Достигни своих целей' :
               language === 'az' ? 'Hədəflərinə Çat' : 'Achieve Your Goals'}
            </h2>
            <p className="text-lg text-slate-400 max-w-2xl mx-auto">
              {language === 'tr' ? 'Yapay zeka destekli, kişiselleştirilmiş antrenman programı' : 
               language === 'ru' ? 'Индивидуальная программа тренировок с поддержкой ИИ' :
               language === 'az' ? 'Süni intellekt dəstəkli, fərdiləşdirilmiş məşq proqramı' : 
               'AI-powered personalized workout program'}
            </p>
          </div>
        )}

        {/* User Info Form */}
        {!showProgram && (
          <Card className="max-w-3xl mx-auto bg-slate-800/50 border-white/10 backdrop-blur-sm animate-slideIn">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-white">
                <User className="w-5 h-5 text-indigo-400" />
                {t.yourInfo}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Profile Photo Upload */}
              <div className="flex justify-center pb-6 border-b border-white/10">
                <div className="text-center">
                  <p className="text-slate-400 text-sm mb-4">{extT.profilePhoto}</p>
                  <ProfileUpload 
                    onImageSelect={handleImageSelect}
                    selectedImage={profileImage}
                    t={{ addPhoto: extT.addPhoto, remove: extT.remove, dragDrop: extT.dragDrop }}
                  />
                </div>
              </div>
              
              {/* Height & Weight */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-slate-300 flex items-center gap-2">
                    <Ruler className="w-4 h-4 text-indigo-400" />
                    {t.height}
                  </Label>
                  <Input
                    type="number"
                    value={height}
                    onChange={(e) => setHeight(e.target.value)}
                    placeholder="175"
                    className="bg-slate-900/50 border-white/10 text-white placeholder:text-slate-500"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="text-slate-300 flex items-center gap-2">
                    <Scale className="w-4 h-4 text-indigo-400" />
                    {t.weight}
                  </Label>
                  <Input
                    type="number"
                    value={weight}
                    onChange={(e) => setWeight(e.target.value)}
                    placeholder="70"
                    className="bg-slate-900/50 border-white/10 text-white placeholder:text-slate-500"
                  />
                </div>
              </div>
              
              {/* Age & Gender */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-slate-300 flex items-center gap-2">
                    <Clock className="w-4 h-4 text-indigo-400" />
                    {t.age}
                  </Label>
                  <Input
                    type="number"
                    value={age}
                    onChange={(e) => setAge(e.target.value)}
                    placeholder="25"
                    className="bg-slate-900/50 border-white/10 text-white placeholder:text-slate-500"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="text-slate-300">{t.gender}</Label>
                  <RadioGroup
                    value={gender}
                    onValueChange={(v) => setGender(v as 'male' | 'female')}
                    className="flex gap-4"
                  >
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="male" id="male" className="border-white/30" />
                      <Label htmlFor="male" className="text-slate-300 cursor-pointer">{t.male}</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="female" id="female" className="border-white/30" />
                      <Label htmlFor="female" className="text-slate-300 cursor-pointer">{t.female}</Label>
                    </div>
                  </RadioGroup>
                </div>
              </div>
              
              {/* Goal */}
              <div className="space-y-2">
                <Label className="text-slate-300 flex items-center gap-2">
                  <Target className="w-4 h-4 text-indigo-400" />
                  {t.goal}
                </Label>
                <RadioGroup
                  value={goal}
                  onValueChange={(v) => setGoal(v as typeof goal)}
                  className="grid grid-cols-1 sm:grid-cols-3 gap-3"
                >
                  {[
                    { value: 'loseWeight', label: t.loseWeight, icon: Flame },
                    { value: 'buildMuscle', label: t.buildMuscle, icon: Dumbbell },
                    { value: 'maintain', label: t.maintain, icon: Activity },
                  ].map((item) => (
                    <div key={item.value}>
                      <RadioGroupItem
                        value={item.value}
                        id={item.value}
                        className="peer sr-only"
                      />
                      <Label
                        htmlFor={item.value}
                        className="flex flex-col items-center gap-2 p-4 rounded-xl border border-white/10 bg-slate-900/30 hover:bg-slate-700/50 peer-data-[state=checked]:border-indigo-500 peer-data-[state=checked]:bg-indigo-500/20 cursor-pointer transition-all"
                      >
                        <item.icon className="w-6 h-6 text-indigo-400" />
                        <span className="text-slate-300 text-sm text-center">{item.label}</span>
                      </Label>
                    </div>
                  ))}
                </RadioGroup>
              </div>
              
              {/* Experience */}
              <div className="space-y-2">
                <Label className="text-slate-300 flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-indigo-400" />
                  {t.experience}
                </Label>
                <Select value={experience} onValueChange={(v) => setExperience(v as typeof experience)}>
                  <SelectTrigger className="bg-slate-900/50 border-white/10 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-800 border-white/10">
                    <SelectItem value="beginner" className="text-white">{t.beginner}</SelectItem>
                    <SelectItem value="intermediate" className="text-white">{t.intermediate}</SelectItem>
                    <SelectItem value="advanced" className="text-white">{t.advanced}</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              {/* Training Frequency */}
              <div className="space-y-2">
                <Label className="text-slate-300 flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-indigo-400" />
                  {t.trainingFrequency}
                </Label>
                <div className="grid grid-cols-4 gap-3">
                  {[3, 4, 5, 6].map((days) => (
                    <button
                      key={days}
                      onClick={() => setTrainingDays(days as 3 | 4 | 5 | 6)}
                      className={`p-4 rounded-xl border transition-all ${
                        trainingDays === days
                          ? 'border-indigo-500 bg-indigo-500/20 text-white'
                          : 'border-white/10 bg-slate-900/30 text-slate-400 hover:bg-slate-700/50'
                      }`}
                    >
                      <div className="text-2xl font-bold">{days}</div>
                      <div className="text-xs">{t.daysPerWeek}</div>
                    </button>
                  ))}
                </div>
              </div>
              
              {/* Buttons */}
              <div className="flex gap-3 pt-4">
                <Button
                  onClick={handleGenerateProgram}
                  className="flex-1 gradient-primary hover:opacity-90 text-white font-semibold py-6"
                >
                  <Dumbbell className="w-5 h-5 mr-2" />
                  {t.generateProgram}
                </Button>
                <Button
                  onClick={handleReset}
                  variant="outline"
                  className="border-white/20 text-slate-300 hover:bg-white/10"
                >
                  <RotateCcw className="w-5 h-5" />
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Results Section */}
        {showProgram && userStats && (
          <div className="animate-fadeIn space-y-6">
            {/* Profile Header with Photo */}
            <div className="flex items-center gap-4 mb-6">
              {profileImage && (
                <img 
                  src={profileImage} 
                  alt="Profile" 
                  className="w-16 h-16 rounded-full object-cover border-2 border-indigo-500"
                />
              )}
              <div>
                <h2 className="text-2xl font-bold text-white">
                  {language === 'tr' ? 'Programınız Hazır!' : 
                   language === 'ru' ? 'Ваша программа готова!' :
                   language === 'az' ? 'Proqramınız Hazırdır!' : 'Your Program is Ready!'}
                </h2>
                <p className="text-slate-400">
                  {language === 'tr' ? 'Hedeflerinize uygun antrenman planı' :
                   language === 'ru' ? 'План тренировок, соответствующий вашим целям' :
                   language === 'az' ? 'Hədəflərinizə uyğun məşq planı' :
                   'Workout plan tailored to your goals'}
                </p>
              </div>
            </div>

            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card className="bg-slate-800/50 border-white/10">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-slate-400 text-sm">{t.bmi}</p>
                      <p className="text-3xl font-bold text-white">{userStats.bmi.value}</p>
                      <Badge className={`mt-2 ${getBMIColor(userStats.bmi.category)}`}>
                        {getBMICategoryText(userStats.bmi.category)}
                      </Badge>
                    </div>
                    <Activity className="w-12 h-12 text-indigo-400 opacity-50" />
                  </div>
                </CardContent>
              </Card>
              
              <Card className="bg-slate-800/50 border-white/10">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-slate-400 text-sm">{t.recommendedCalories}</p>
                      <p className="text-3xl font-bold text-white">{userStats.calories}</p>
                      <p className="text-slate-400 text-sm">{t.perDay}</p>
                    </div>
                    <Flame className="w-12 h-12 text-orange-400 opacity-50" />
                  </div>
                </CardContent>
              </Card>
              
              <Card className="bg-slate-800/50 border-white/10">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-slate-400 text-sm">{t.trainingFrequency}</p>
                      <p className="text-3xl font-bold text-white">{trainingDays}</p>
                      <p className="text-slate-400 text-sm">{t.daysPerWeek}</p>
                    </div>
                    <Calendar className="w-12 h-12 text-emerald-400 opacity-50" />
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Program Tabs */}
            <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as 'standard' | 'ai')}>
              <TabsList className="grid w-full grid-cols-2 bg-slate-800/50">
                <TabsTrigger value="standard" className="data-[state=active]:bg-indigo-600">
                  {extT.standardProgram}
                </TabsTrigger>
                <TabsTrigger value="ai" className="data-[state=active]:bg-indigo-600">
                  <Sparkles className="w-4 h-4 mr-2" />
                  {extT.aiProgram}
                </TabsTrigger>
              </TabsList>

              <TabsContent value="standard" className="mt-6">
                {/* Standard Program */}
                <div>
                  <h3 className="text-2xl font-bold text-white mb-4 flex items-center gap-2">
                    <Calendar className="w-6 h-6 text-indigo-400" />
                    {t.weeklySchedule}
                  </h3>
                  
                  <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-4">
                    {program.map((day, index) => (
                      <Card 
                        key={index} 
                        className={`border-white/10 ${
                          day.isRestDay 
                            ? 'bg-slate-800/30' 
                            : 'bg-slate-800/50'
                        }`}
                      >
                        <CardHeader className="pb-3">
                          <div className="flex items-center justify-between">
                            <CardTitle className="text-lg text-white">
                              {t.day} {day.day}
                            </CardTitle>
                            {day.isRestDay ? (
                              <Badge variant="outline" className="border-slate-500 text-slate-400">
                                {t.restDay}
                              </Badge>
                            ) : (
                              <Badge className="bg-indigo-500/20 text-indigo-300 border-indigo-500/30">
                                {day.focus?.[language]}
                              </Badge>
                            )}
                          </div>
                        </CardHeader>
                        {!day.isRestDay && day.exercises && (
                          <CardContent>
                            <ul className="space-y-2">
                              {day.exercises.map((exercise, exIndex) => (
                                <li 
                                  key={exIndex}
                                  className="flex items-center justify-between py-2 px-3 rounded-lg bg-slate-900/50"
                                >
                                  <span className="text-slate-300 text-sm">
                                    {exercise.name[language]}
                                  </span>
                                  <span className="text-indigo-400 text-xs font-medium">
                                    {exercise.sets} {t.sets} × {exercise.reps}
                                  </span>
                                </li>
                              ))}
                            </ul>
                          </CardContent>
                        )}
                      </Card>
                    ))}
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="ai" className="mt-6">
                {/* AI Program */}
                <AIProgramGenerator 
                  userProfile={getUserProfile()}
                  language={language}
                  t={t}
                />
              </TabsContent>
            </Tabs>

            {/* Back Button */}
            <div className="flex justify-center pt-6">
              <Button
                onClick={handleReset}
                variant="outline"
                className="border-white/20 text-slate-300 hover:bg-white/10 px-8"
              >
                <RotateCcw className="w-4 h-4 mr-2" />
                {t.reset}
              </Button>
            </div>
          </div>
        )}
      </main>

      {/* AI Chatbot */}
      <AIChatbot 
        isOpen={chatbotOpen}
        onClose={() => setChatbotOpen(false)}
        userProfile={showProgram ? getUserProfile() : null}
        language={language}
      />

      {/* Mobile AI Button */}
      <button
        onClick={() => setChatbotOpen(!chatbotOpen)}
        className="fixed bottom-4 right-4 sm:hidden w-14 h-14 bg-indigo-600 rounded-full flex items-center justify-center shadow-lg z-40"
      >
        <Bot className="w-6 h-6 text-white" />
      </button>

      {/* Footer */}
      <footer className="border-t border-white/10 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <Dumbbell className="w-5 h-5 text-indigo-400" />
              <span className="text-white font-semibold">{t.appName}</span>
            </div>
            <p className="text-slate-400 text-sm">
              © 2025 Fitzo. {language === 'tr' ? 'Tüm hakları saklıdır.' : 
                              language === 'ru' ? 'Все права защищены.' :
                              language === 'az' ? 'Bütün hüquqlar qorunur.' : 'All rights reserved.'}
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;
